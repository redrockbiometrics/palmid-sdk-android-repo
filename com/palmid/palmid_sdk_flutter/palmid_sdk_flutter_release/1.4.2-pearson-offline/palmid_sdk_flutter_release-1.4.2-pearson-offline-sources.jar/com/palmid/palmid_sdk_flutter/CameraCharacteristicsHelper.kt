package com.palmid.palmid_sdk_flutter

import android.graphics.ImageFormat
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.MeteringRectangle
import android.os.Build
import android.util.Range
import android.util.Size
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class CameraCharacteristicsHelper(
    private val characteristics: CameraCharacteristics,
    private val targetFps: Int
) {

    val hasTorch: Boolean
        get() = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false

    val isTorchForStillCaptureSupported: Boolean
        get() = get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL) != CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY
//    {
//            val brand = Build.BRAND.lowercase(Locale.US)
//            val model = Build.MODEL.lowercase(Locale.US)
//            val noSupport = brand.contains("oukitel") && model.contains("c17")
//                    || brand.contains("xiaomi") && model.contains("4x")
//                    || brand.contains("oppo") && model.contains("cph1909")
//            return !noSupport
//        }

    val sensorOrientation: Int
        get() = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0

    val isFrontFacing: Boolean
        get() = characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT

    fun <T> get(key: CameraCharacteristics.Key<T>): T? = characteristics.get(key)

    val aeFps: Range<Int>
        get() {
            val ranges =
                characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)!!
            val range = ranges.filter { it.upper >= targetFps && it.lower >= targetFps }
                .minByOrNull { it.upper + it.lower }
            return range ?: ranges.maxBy { it.upper + it.lower }
        }

    val maxJpegSize: Size
        get() {
            val map =
                characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            var sizes = map.getHighResolutionOutputSizes(ImageFormat.JPEG)
            if (sizes == null || sizes.isEmpty()) {
                sizes = map.getOutputSizes(ImageFormat.JPEG)
            }
            return sizes.maxBy { it.width * it.height }
        }

    val isAutoFocusEnabled: Boolean
        get() {
            if (isEmulator) {
                return false
            }
            val modes = characteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            if (modes?.isEmpty() != false) {
                return false
            }
            return (modes.size > 1 || modes[0] != CameraCharacteristics.CONTROL_AF_MODE_OFF)
        }

    val adjustedFocusRange: Range<Float>
        get() {
            val cal =
                characteristics.get(CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION)
            return if (cal == CameraMetadata.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_APPROXIMATE ||
                cal == CameraMetadata.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_CALIBRATED
            ) {
                Range(2f, Float.POSITIVE_INFINITY)
            } else {
                Range(0f, Float.POSITIVE_INFINITY)
            }
        }

    val minFocusDistance: Float
        get() {
            val distance =
                characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)
            return if (isAutoFocusEnabled && distance != null) distance else 15.0F
        }

    val maxIso: Int?
        get() = characteristics.get(CameraCharacteristics.SENSOR_MAX_ANALOG_SENSITIVITY)

    val gainRange: Range<Int>
        get() =
            characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(
                Int.MIN_VALUE,
                Int.MAX_VALUE
            )

    private val sensorRect: Rect?
        get() {
            val rect =
                characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                    ?: return null
            rect.apply {
                right -= left
                left = 0
                bottom -= top
                top = 0
            }

            if (rect.width() <= 0 || rect.height() <= 0) {
                return null
            }
            return rect
        }

    fun buildAfRegions(): Array<MeteringRectangle>? {
        val regions = characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)
        if (regions == null || regions < 1) {
            return null
        }

        val rect = sensorRect ?: return null

        val size = (min(rect.width(), rect.height()) * 0.5).toInt()

        return arrayOf(
            MeteringRectangle(
                rect.centerRect(size, size),
                MeteringRectangle.METERING_WEIGHT_MAX - 1
            )
        )
    }

    fun buildAeRegions(): Array<MeteringRectangle>? {
        val regions = characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)
        if (regions == null || regions < 1) {
            return null
        }

        val rect = sensorRect ?: return null
        val size = (min(rect.width(), rect.height()) * 0.5).toInt()

        return arrayOf(
            MeteringRectangle(
                rect.centerRect(size, size),
                MeteringRectangle.METERING_WEIGHT_MAX
            )
        )
    }

    fun getCropRegionForZoom(zoom: Float): Rect {
        val rect = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!

        val dx = (rect.width() - rect.width() / zoom).toInt() / 2
        val dy = (rect.height() - rect.height() / zoom).toInt() / 2
        return Rect(dx, dy, rect.width() - dx, rect.height() - dy)
    }

    fun getZoomLevelForArea(minSubjectSize: Int): Float {
        if (minSubjectSize <= 0) return 1f

        val maxZoom = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
            ?: return 1f

        val minFocusDistance =
            characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)
                ?: return 1f
        if (minFocusDistance == 0f) return 1f

        val minFocusDistanceMm = 1000 / minFocusDistance

        val size =
            characteristics.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return 1f
        val sensorSize = min(size.width, size.height)

        val focalLen =
            characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                ?.firstOrNull()
                ?: return 1f

        val d = focalLen * minFocusDistanceMm / (minFocusDistanceMm - focalLen)

        val minDistanceSubject = minSubjectSize * d / sensorSize

        return min(max(1f, minFocusDistanceMm / minDistanceSubject), maxZoom)
    }

    val isFamocoDevice: Boolean
        get() = Build.MANUFACTURER.lowercase(Locale.US).contains("famoco")

    val isSamsungDevice: Boolean
        get() = Build.MANUFACTURER.lowercase().contains("samsung")

    val isMotorolaDevice: Boolean
        get() = Build.MANUFACTURER.lowercase().contains("motorola")

    val isEmulator: Boolean
        get() = ((Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
            || Build.FINGERPRINT.startsWith("generic")
            || Build.FINGERPRINT.startsWith("unknown")
            || Build.HARDWARE.contains("goldfish")
            || Build.HARDWARE.contains("ranchu")
            || Build.MODEL.contains("google_sdk")
            || Build.MODEL.contains("Emulator")
            || Build.MODEL.contains("Android SDK built for x86")
            || Build.MANUFACTURER.contains("Genymotion")
            || Build.PRODUCT.contains("sdk")
            || Build.PRODUCT.contains("vbox86p")
            || Build.PRODUCT.contains("emulator")
            || Build.PRODUCT.contains("simulator"))
}

fun Rect.centerRect(width: Int, height: Int): Rect =
    Rect(
        (this.width() - width) / 2,
        (this.height() - height) / 2,
        (this.width() - width) / 2 + width,
        (this.height() - height) / 2 + height,
    )