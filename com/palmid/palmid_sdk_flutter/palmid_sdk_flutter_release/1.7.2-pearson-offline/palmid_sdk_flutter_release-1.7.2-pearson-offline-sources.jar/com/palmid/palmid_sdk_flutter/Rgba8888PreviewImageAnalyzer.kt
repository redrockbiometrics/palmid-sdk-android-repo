package com.palmid.palmid_sdk_flutter

import android.graphics.PixelFormat
import android.util.Log
import androidx.camera.core.ImageProxy

class Rgba8888PreviewImageAnalyzer(
    private val cameraState: CameraState,
    private val isActiveLighting: Boolean,
    private val isRearFacingCamera: Boolean,
    override var dropFramesWhenCameraAdjusting: Boolean,
    override var onImage: (CameraImage) -> Unit,
) : IPreviewImageAnalyzer {
    private var src = ByteArray(0)
    private var dst = ByteArray(0)

    override fun analyze(image: ImageProxy) {
        try {
            if (image.format !=  PixelFormat.RGBA_8888) {
                throw UnsupportedOperationException("Invalid image format")
            }
            val isCameraAdjusted = cameraState.isAdjusted
            if (dropFramesWhenCameraAdjusting && !isCameraAdjusted) {
                return
            }
            val planes = image.planes
            if (planes.isEmpty()) {
                throw UnsupportedOperationException("Invalid image planes")
            }

            val buffer = planes[0].buffer
            val width = image.width
            val height = image.height
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * width

            if (dst.size != width * height * 4) {
                dst = ByteArray(width * height * 4)
            }

            if (rowPadding == 0) {
                buffer.get(dst)
            } else {
                if (src.size != buffer.remaining()) {
                    src = ByteArray(buffer.remaining())
                }
                buffer.get(src)

                for (y in 0 until height) {
                    System.arraycopy(
                        src,
                        rowStride * y,
                        dst,
                        width * pixelStride * y,
                        width * pixelStride
                    )
                }
            }

            onImage(
                CameraImage(
                    width = width.toLong(),
                    height = height.toLong(),
                    format = CameraImageFormat.RGBA8888,
                    planes = listOf(dst),
                    isActiveLighting = isActiveLighting,
                    isRearFacingCamera = isRearFacingCamera,
                    isCameraAdjusted = isCameraAdjusted,
                    timestamp = image.imageInfo.timestamp,
                    metadata = mutableMapOf()
                )
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Error analysing image", e)
        } finally {
            image.close()
        }
    }

    companion object {
        const val TAG = "ImageAnalyzer"
    }
}