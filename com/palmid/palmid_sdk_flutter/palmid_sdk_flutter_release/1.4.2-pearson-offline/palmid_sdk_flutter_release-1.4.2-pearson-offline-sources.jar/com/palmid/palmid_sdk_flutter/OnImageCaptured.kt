package com.palmid.palmid_sdk_flutter

import android.graphics.ImageFormat
import android.util.Log
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageProxy

class OnImageCaptured(
    private val isActiveLighting: Boolean,
    private val isRearFacingCamera: Boolean,
    override var onImage: (CameraImage) -> Unit,
) : ImageCapture.OnImageCapturedCallback(), ICameraImageProducer {
    override fun onCaptureSuccess(image: ImageProxy) {
        try {
            if (image.format != ImageFormat.JPEG) {
                throw UnsupportedOperationException("Invalid image format")
            }
            val planes = image.planes
            if (planes.isEmpty()) {
                throw UnsupportedOperationException("Invalid image planes")
            }

            val buffer = planes[0].buffer
            val width = image.width
            val height = image.height

            val n = buffer.remaining()
            val dst = ByteArray(n)
            buffer.get(dst)

            onImage(
                CameraImage(
                    width = width.toLong(),
                    height = height.toLong(),
                    format = CameraImageFormat.JPEG,
                    planes = listOf(dst),
                    isActiveLighting = isActiveLighting,
                    isRearFacingCamera = isRearFacingCamera,
                    isCameraAdjusted = true,
                    timestamp = image.imageInfo.timestamp,
                    metadata = mutableMapOf()
                )
            )
        } catch (e: Throwable) {
            Log.e("CameraXController.OnImageCapture", "Error processing the image", e)
        } finally {
            image.close()
        }
    }
}