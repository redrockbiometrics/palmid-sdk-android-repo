package com.palmid.palmid_sdk_flutter

import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult

class CameraImageProducer(
    imageSource: ICameraImageProducer,
    val cameraState: CameraState,
    val forStillCapture: Boolean = false,
) :
    ICameraImageProducer {
    override var onImage: (CameraImage) -> Unit = {}
    var onFocused: (CameraState) -> Unit = {}

    private val buffer = CircularDataBuffer(5)
    private var lastFocusedFrames = 0
    private val minLastFocusedFrames = 3

    init {
        imageSource.onImage = {
            val ts = it.timestamp
            var runOnImage = false
            synchronized(buffer) {
                val state = buffer.findCaptureResult(ts)
                if (state != null) {
                    it.setMetadata(state)
                    buffer.remove(ts)
                    runOnImage = true
                } else {
                    buffer.add(ts, it, null)
                }
            }
            if (runOnImage) {
                onImage(it)
            }
        }
    }

    val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            super.onCaptureCompleted(session, request, result)
            if (forStillCapture && result.get(CaptureResult.CONTROL_CAPTURE_INTENT) != CaptureResult.CONTROL_CAPTURE_INTENT_STILL_CAPTURE) {
                return
            }

            val state = cameraState.copy()

            state.afState = result.get(CaptureResult.CONTROL_AF_STATE)
                ?: CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED
            state.aeState = result.get(CaptureResult.CONTROL_AE_STATE)
                ?: CaptureResult.CONTROL_AE_STATE_CONVERGED

            state.exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            state.rawGain = result.get(CaptureResult.SENSOR_SENSITIVITY)
            state.focusDistance = result.get(CaptureResult.LENS_FOCUS_DISTANCE)

            cameraState.updateFrom(state)

            if (state.isFocused) {
                lastFocusedFrames++
            } else {
                lastFocusedFrames = 0
            }
            if (lastFocusedFrames >= minLastFocusedFrames) {
                onFocused(state.copy())
            }

            val ts = result.getTimestamp()

            var image: CameraImage?
            synchronized(buffer) {
                image = buffer.findCameraImage(ts)
                if (image == null) {
                    buffer.add(ts, null, state)
                } else {
                    buffer.remove(ts)
                }
            }
            image?.also {
                it.setMetadata(state)
                onImage(it)
            }
        }
    }
}

interface ICameraImageProducer {
    var onImage: (CameraImage) -> Unit
}

class CircularDataBuffer(private val maxSize: Int) {
    data class Data(
        val timestamp: Long,
        var image: CameraImage?,
        var cameraState: CameraState?
    )

    private val buffer: ArrayDeque<Data> = ArrayDeque(maxSize)
    fun findCameraImage(timestamp: Long): CameraImage? {
        return buffer.firstOrNull { it.timestamp == timestamp }?.image
    }

    fun findCaptureResult(timestamp: Long): CameraState? {
        return buffer.firstOrNull { it.timestamp == timestamp }?.cameraState
    }

    fun add(timestamp: Long, image: CameraImage?, cameraState: CameraState?) {
        if (maxSize <= buffer.size) {
            buffer.removeLast()
        }

        buffer.addFirst(Data(timestamp, image, cameraState))
    }

    fun remove(timestamp: Long) {
        buffer.firstOrNull { it.timestamp == timestamp }?.also {
            buffer.remove(it)
        }
    }
}

fun TotalCaptureResult.getTimestamp(): Long {
    return get(CaptureResult.SENSOR_TIMESTAMP)!!
}

fun CameraImage.setMetadata(cameraState: CameraState) {
    val metadata = this.metadata as MutableMap<String?, Any?>? ?: mutableMapOf()
    metadata["af"] = cameraState.isFocused
    metadata["ae"] = cameraState.isExposureFinished
    metadata["fd"] = cameraState.focusDistance
    metadata["ex"] = cameraState.exposure
}
