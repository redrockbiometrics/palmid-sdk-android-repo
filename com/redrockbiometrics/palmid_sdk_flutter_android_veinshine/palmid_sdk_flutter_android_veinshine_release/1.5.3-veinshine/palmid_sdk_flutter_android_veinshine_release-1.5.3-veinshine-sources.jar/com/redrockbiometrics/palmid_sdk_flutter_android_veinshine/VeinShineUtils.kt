package com.redrockbiometrics.palmid_sdk_flutter_android_veinshine

import android.util.Log

class VeinShineUtils {
    companion object {
        private const val TAG = "VeinShineUtils"
        private var nativeLibLoaded = false

        init {
            try {
                System.loadLibrary("veinshine_utils")
                nativeLibLoaded = true
                Log.i(TAG, "✅ Native library loaded successfully - CPU optimization enabled")
            } catch (e: UnsatisfiedLinkError) {
                Log.w(TAG, "⚠️ Failed to load native library, falling back to Kotlin implementation", e)
                nativeLibLoaded = false
            }
        }

        /**
         * Convert RGB888 to ARGB8888 format using native implementation for better performance.
         * Falls back to Kotlin implementation if native library is not available.
         */
        fun convertRgbToArgb8888(source: ByteArray, destination: IntArray) {
            if (nativeLibLoaded) {
                try {
                    convertRgbToArgb8888Native(source, destination)
                    return
                } catch (e: Exception) {
                    Log.w(TAG, "Native RGB conversion failed, falling back to Kotlin", e)
                }
            }
            // Fallback to Kotlin implementation
            convertRgbToArgb8888Kotlin(source, destination)
        }

        /**
         * Convert IR (Y8/Grayscale) to ARGB8888 format using native implementation for better performance.
         * Falls back to Kotlin implementation if native library is not available.
         */
        fun convertIrToArgb8888(source: ByteArray, destination: IntArray) {
            if (nativeLibLoaded) {
                try {
                    convertIrToArgb8888Native(source, destination)
                    return
                } catch (e: Exception) {
                    Log.w(TAG, "Native IR conversion failed, falling back to Kotlin", e)
                }
            }
            // Fallback to Kotlin implementation
            convertIrToArgb8888Kotlin(source, destination)
        }

        // Native method declarations
        @JvmStatic
        private external fun convertRgbToArgb8888Native(source: ByteArray, destination: IntArray)

        @JvmStatic
        private external fun convertIrToArgb8888Native(source: ByteArray, destination: IntArray)

        // Kotlin fallback implementations
        private fun convertRgbToArgb8888Kotlin(source: ByteArray, destination: IntArray) {
            var srcIndex = 0
            val totalPixels = destination.size
            for (i in 0 until totalPixels) {
                if (srcIndex + 2 >= source.size) {
                    destination[i] = 0xFF000000.toInt()
                    continue
                }
                val b = source[srcIndex++].toInt() and 0xFF
                val g = source[srcIndex++].toInt() and 0xFF
                val r = source[srcIndex++].toInt() and 0xFF
                destination[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        private fun convertIrToArgb8888Kotlin(source: ByteArray, destination: IntArray) {
            val totalPixels = destination.size
            for (i in 0 until totalPixels) {
                val value = if (i < source.size) source[i].toInt() and 0xFF else 0
                destination[i] = (0xFF shl 24) or (value shl 16) or (value shl 8) or value
            }
        }
    }
}