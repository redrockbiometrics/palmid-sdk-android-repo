package com.redrockbiometrics.palmid_sdk_flutter_android_veinshine

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * OpenGL ES 2.0 渲染器，直接渲染到 Flutter Surface
 * 使用 GPU 进行像素格式转换和渲染，大幅降低 CPU 负载
 */
class SurfaceGLRenderer(
    private val surface: Surface,
    private val width: Int,
    private val height: Int
) {
    companion object {
        private const val TAG = "SurfaceGLRenderer"

        // Vertex Shader
        private const val VERTEX_SHADER = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = aTexCoord;
            }
        """

        // Fragment Shader for RGB (BGR -> RGB)
        private const val FRAGMENT_SHADER_RGB = """
            precision mediump float;
            uniform sampler2D uTexture;
            varying vec2 vTexCoord;
            void main() {
                vec4 color = texture2D(uTexture, vTexCoord);
                gl_FragColor = vec4(color.b, color.g, color.r, 1.0);
            }
        """

        // Fragment Shader for Grayscale
        private const val FRAGMENT_SHADER_GRAY = """
            precision mediump float;
            uniform sampler2D uTexture;
            varying vec2 vTexCoord;
            void main() {
                float gray = texture2D(uTexture, vTexCoord).r;
                gl_FragColor = vec4(gray, gray, gray, 1.0);
            }
        """

        // 顶点坐标
        private val VERTICES = floatArrayOf(
            -1.0f, -1.0f,
             1.0f, -1.0f,
            -1.0f,  1.0f,
             1.0f,  1.0f
        )

        // 纹理坐标 (Y轴翻转)
        private val TEX_COORDS = floatArrayOf(
            0.0f, 1.0f,
            1.0f, 1.0f,
            0.0f, 0.0f,
            1.0f, 0.0f
        )
    }

    // EGL 对象
    private var eglDisplay: EGLDisplay? = null
    private var eglContext: EGLContext? = null
    private var eglSurface: EGLSurface? = null

    // OpenGL 对象
    private var rgbProgram = 0
    private var grayProgram = 0
    private var textureId = 0

    // 缓冲区
    private val vertexBuffer: FloatBuffer
    private val texCoordBuffer: FloatBuffer

    // 可复用的纹理数据缓冲区 - 避免每帧分配
    private var rgbTextureBuffer: ByteBuffer? = null
    private var grayTextureBuffer: ByteBuffer? = null

    private var initialized = false

    init {
        vertexBuffer = ByteBuffer.allocateDirect(VERTICES.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(VERTICES)
                position(0)
            }

        texCoordBuffer = ByteBuffer.allocateDirect(TEX_COORDS.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(TEX_COORDS)
                position(0)
            }
    }

    /**
     * 初始化 OpenGL ES 上下文
     */
    fun initialize(): Boolean {
        if (initialized) return true

        try {
            // 1. 获取 EGL Display
            eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (eglDisplay == EGL14.EGL_NO_DISPLAY) {
                Log.e(TAG, "Failed to get EGL display")
                return false
            }

            // 2. 初始化 EGL
            val version = IntArray(2)
            if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
                Log.e(TAG, "Failed to initialize EGL")
                return false
            }

            // 3. 选择配置
            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_DEPTH_SIZE, 0,
                EGL14.EGL_STENCIL_SIZE, 0,
                EGL14.EGL_NONE
            )

            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            if (!EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, numConfigs, 0)) {
                Log.e(TAG, "Failed to choose EGL config")
                return false
            }

            // 4. 创建 EGL Context
            val contextAttribs = intArrayOf(
                EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
                EGL14.EGL_NONE
            )
            eglContext = EGL14.eglCreateContext(
                eglDisplay,
                configs[0],
                EGL14.EGL_NO_CONTEXT,
                contextAttribs,
                0
            )
            if (eglContext == EGL14.EGL_NO_CONTEXT) {
                Log.e(TAG, "Failed to create EGL context")
                return false
            }

            // 5. 创建 Window Surface
            val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
            eglSurface = EGL14.eglCreateWindowSurface(
                eglDisplay,
                configs[0],
                surface,
                surfaceAttribs,
                0
            )
            if (eglSurface == EGL14.EGL_NO_SURFACE) {
                Log.e(TAG, "Failed to create EGL surface")
                return false
            }

            // 6. 绑定上下文
            if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
                Log.e(TAG, "Failed to make EGL context current")
                return false
            }

            // 7. 初始化 OpenGL
            initializeGL()

            initialized = true
            Log.i(TAG, "✅ OpenGL ES initialized - GPU rendering enabled")
            return true

        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize OpenGL", e)
            release()
            return false
        }
    }

    private fun initializeGL() {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
        GLES20.glViewport(0, 0, width, height)

        // 创建着色器程序
        rgbProgram = createProgram(VERTEX_SHADER, FRAGMENT_SHADER_RGB)
        grayProgram = createProgram(VERTEX_SHADER, FRAGMENT_SHADER_GRAY)

        // 生成纹理
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]

        // 配置纹理
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    /**
     * 渲染 RGB 数据 - 使用可复用的 ByteBuffer 减少内存分配
     */
    fun renderRGB(data: ByteArray, imgWidth: Int, imgHeight: Int) {
        if (!initialized) {
            if (!initialize()) return
        }

        makeCurrent()

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(rgbProgram)

        // 复用或创建 ByteBuffer
        val buffer = ensureRgbBuffer(data.size)
        buffer.clear()
        buffer.put(data)
        buffer.position(0)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D,
            0,
            GLES20.GL_RGB,
            imgWidth,
            imgHeight,
            0,
            GLES20.GL_RGB,
            GLES20.GL_UNSIGNED_BYTE,
            buffer
        )

        drawQuad(rgbProgram)
        swapBuffers()
    }

    /**
     * 渲染灰度数据 - 使用可复用的 ByteBuffer 减少内存分配
     */
    fun renderGray(data: ByteArray, imgWidth: Int, imgHeight: Int) {
        if (!initialized) {
            if (!initialize()) return
        }

        makeCurrent()

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(grayProgram)

        // 复用或创建 ByteBuffer
        val buffer = ensureGrayBuffer(data.size)
        buffer.clear()
        buffer.put(data)
        buffer.position(0)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D,
            0,
            GLES20.GL_LUMINANCE,
            imgWidth,
            imgHeight,
            0,
            GLES20.GL_LUMINANCE,
            GLES20.GL_UNSIGNED_BYTE,
            buffer
        )

        drawQuad(grayProgram)
        swapBuffers()
    }

    /**
     * 确保 RGB ByteBuffer 足够大，复用以避免每帧分配
     */
    private fun ensureRgbBuffer(requiredSize: Int): ByteBuffer {
        val current = rgbTextureBuffer
        if (current == null || current.capacity() < requiredSize) {
            rgbTextureBuffer = ByteBuffer.allocateDirect(requiredSize).order(ByteOrder.nativeOrder())
            Log.d(TAG, "Allocated RGB buffer: ${requiredSize} bytes")
        }
        return rgbTextureBuffer!!
    }

    /**
     * 确保 Gray ByteBuffer 足够大，复用以避免每帧分配
     */
    private fun ensureGrayBuffer(requiredSize: Int): ByteBuffer {
        val current = grayTextureBuffer
        if (current == null || current.capacity() < requiredSize) {
            grayTextureBuffer = ByteBuffer.allocateDirect(requiredSize).order(ByteOrder.nativeOrder())
            Log.d(TAG, "Allocated Gray buffer: ${requiredSize} bytes")
        }
        return grayTextureBuffer!!
    }

    private fun drawQuad(program: Int) {
        val posHandle = GLES20.glGetAttribLocation(program, "aPosition")
        val texHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
        val samplerHandle = GLES20.glGetUniformLocation(program, "uTexture")

        GLES20.glEnableVertexAttribArray(posHandle)
        GLES20.glVertexAttribPointer(posHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        GLES20.glEnableVertexAttribArray(texHandle)
        GLES20.glVertexAttribPointer(texHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)

        GLES20.glUniform1i(samplerHandle, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(posHandle)
        GLES20.glDisableVertexAttribArray(texHandle)
    }

    private fun makeCurrent() {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
    }

    private fun swapBuffers() {
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    private fun createProgram(vertexShader: String, fragmentShader: String): Int {
        val vs = loadShader(GLES20.GL_VERTEX_SHADER, vertexShader)
        val fs = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShader)

        return GLES20.glCreateProgram().also { program ->
            GLES20.glAttachShader(program, vs)
            GLES20.glAttachShader(program, fs)
            GLES20.glLinkProgram(program)

            val linkStatus = IntArray(1)
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] == 0) {
                val error = GLES20.glGetProgramInfoLog(program)
                GLES20.glDeleteProgram(program)
                throw RuntimeException("Failed to link program: $error")
            }
        }
    }

    private fun loadShader(type: Int, shaderCode: String): Int {
        return GLES20.glCreateShader(type).also { shader ->
            GLES20.glShaderSource(shader, shaderCode)
            GLES20.glCompileShader(shader)

            val compileStatus = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
            if (compileStatus[0] == 0) {
                val error = GLES20.glGetShaderInfoLog(shader)
                GLES20.glDeleteShader(shader)
                throw RuntimeException("Failed to compile shader: $error")
            }
        }
    }

    fun release() {
        // 清理纹理缓冲区
        rgbTextureBuffer = null
        grayTextureBuffer = null

        if (textureId != 0) {
            GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
            textureId = 0
        }

        if (rgbProgram != 0) {
            GLES20.glDeleteProgram(rgbProgram)
            rgbProgram = 0
        }

        if (grayProgram != 0) {
            GLES20.glDeleteProgram(grayProgram)
            grayProgram = 0
        }

        eglSurface?.let {
            EGL14.eglDestroySurface(eglDisplay, it)
            eglSurface = null
        }

        eglContext?.let {
            EGL14.eglDestroyContext(eglDisplay, it)
            eglContext = null
        }

        eglDisplay?.let {
            EGL14.eglTerminate(it)
            eglDisplay = null
        }

        initialized = false
        Log.d(TAG, "OpenGL resources released")
    }
}

