package com.redrockbiometrics.palmid_sdk_flutter_android_veinshine

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.api.stream.PalmSdk
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.view.TextureRegistry
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader


const val TAG = "palmid_veinshine"

/** PalmidSdkFlutterPlugin */
class PalmidSdkFlutterPlugin : FlutterPlugin, ActivityAware {
    private var flutterPluginBinding: FlutterPlugin.FlutterPluginBinding? = null
    private var isPalmSdkInitialized = false
    private var methodCallHandler: PalmidSdkMethodCallHandler? = null

    override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        this.flutterPluginBinding = flutterPluginBinding
        initializePalmSdk()
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        // Dispose handler before detaching engine
        methodCallHandler?.dispose()
        methodCallHandler = null
        this.flutterPluginBinding = null
        cleanupPalmSdk()
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        if (!isPalmSdkInitialized) {
            Log.w(TAG, "PalmSdk not initialized, attempting to initialize now")
            initializePalmSdk()
        }
        
        methodCallHandler = PalmidSdkMethodCallHandler(
            binding.activity,
            flutterPluginBinding!!.textureRegistry,
            CameraControllerFlutterApi(flutterPluginBinding!!.binaryMessenger),
        )
        
        CameraControllerHostApi.setUp(
            flutterPluginBinding!!.binaryMessenger,
            methodCallHandler,
        )
    }

    override fun onDetachedFromActivity() {
        // Dispose all connections before detaching from activity
        methodCallHandler?.dispose()
        CameraControllerHostApi.setUp(
            flutterPluginBinding!!.binaryMessenger,
            null
        )
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity()
    }

    /**
     * Initialize PalmSdk
     */
    private fun initializePalmSdk() {
        if (isPalmSdkInitialized) {
            Log.d(TAG, "PalmSdk already initialized")
            return
        }

        try {
            PalmSdk.initialize()
            isPalmSdkInitialized = true
            Log.d(TAG, "PalmSdk initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize PalmSdk", e)
            isPalmSdkInitialized = false
        }
    }

    /**
     * Clean up PalmSdk resources
     */
    private fun cleanupPalmSdk() {
        if (isPalmSdkInitialized) {
            try {
                isPalmSdkInitialized = false
                Log.d(TAG, "PalmSdk resources cleaned up")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to cleanup PalmSdk resources", e)
            }
        }
    }

    /**
     * Check if PalmSdk is initialized
     */
    fun isPalmSdkReady(): Boolean {
        return isPalmSdkInitialized
    }
}

class PalmidSdkMethodCallHandler(
    private val activity: Activity,
    private val textureRegistry: TextureRegistry,
    private val flutterApi: CameraControllerFlutterApi,
) : CameraControllerHostApi {
    private val openedConnections =
        mutableMapOf<String, Triple<VeinShineCameraController, TextureRegistry.SurfaceProducer, TextureRegistry.SurfaceProducer>>()

    override fun openCamera(
        cameraSelector: CameraSelectorData,
        settings: CameraCaptureSettingsData,
        callback: (Result<CameraInfo>) -> Unit
    ) = callback(runCatching {
        openCameraImpl(cameraSelector, settings)
    })

    override fun captureHiresPhoto(connectionId: String, callback: (Result<CameraImage>) -> Unit) =
        throw NotImplementedError()

    override fun sendCaptureHiresPhotoRequest(connectionId: String) =
        throw NotImplementedError()

    override fun cancelCaptureHiresPhotoRequest(connectionId: String) =
        throw NotImplementedError()

    override fun sendResetAutofocusRequest(connectionId: String) =
        throw NotImplementedError()

    override fun getDebugCameraInfo(cameraSelector: CameraSelectorData): String {
        val props = System.getProperties()
        val e = props.propertyNames()
        var msg = ""
        while (e.hasMoreElements()) {
            val k = e.nextElement() as String
            val v = props.getProperty(k)
            msg += "$k: $v\n"
        }

        try {
            val p = ProcessBuilder("/system/bin/getprop").redirectErrorStream(true).start()
            msg += BufferedReader(InputStreamReader(p.inputStream)).readText()
            p.destroy()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return VeinShineCameraController.getDebugInfo(activity) + "\n\n== getprop:\n$msg"
    }

    override fun setLedMode(connectionId: String, ledMode: Long) {
        val ctr = openedConnections[connectionId]?.first
        ctr?.setLedMode(ledMode)
    }

    override fun setDropFramesDuringCameraAdjustment(connectionId: String, drop: Boolean) =
        throw NotImplementedError()

    private fun closeAllConnections() = openedConnections
        .forEach {
            closeCamera(it.key)
        }

    override fun closeCamera(connectionId: String): Unit = runBlocking {
        openedConnections.remove(connectionId)?.apply { closeOpenedCamera(this) }
    }

    private fun closeOpenedCamera(info: Triple<VeinShineCameraController, TextureRegistry.SurfaceProducer, TextureRegistry.SurfaceProducer>): Unit =
        runBlocking {
            info.first.close()
            info.second.release()
            info.third.release()
        }

    override fun dispose() = runBlocking {
        openedConnections.forEach {
            closeOpenedCamera(it.value)
        }
        openedConnections.clear()
    }

    private fun openCameraImpl(
        cameraSelector: CameraSelectorData,
        settings: CameraCaptureSettingsData
    ): CameraInfo {
        closeAllConnections()

        val isBackCamera = cameraSelector.lensFacing != CameraLensFacing.FRONT

        // Create RGB preview SurfaceProducer
        val rgbPreviewSurfaceProducer = textureRegistry.createSurfaceProducer()
        
        // Create IR preview SurfaceProducer
        val irPreviewSurfaceProducer = textureRegistry.createSurfaceProducer()
        
        val cameraController = VeinShineCameraController(
            activity,
            rgbPreviewSurfaceProducer,
            irPreviewSurfaceProducer,
            false,
        ) {
            Handler(Looper.getMainLooper()).post {
                flutterApi.onImage(it) {}
            }
        }
        
        val rgbPreviewId = rgbPreviewSurfaceProducer.id()
        val irPreviewId = irPreviewSurfaceProducer.id()
        val connectionId = rgbPreviewId.toString()

        cameraController.open()

        // Store two SurfaceProducers for subsequent cleanup
        openedConnections[connectionId] = Triple(cameraController, rgbPreviewSurfaceProducer, irPreviewSurfaceProducer)

        return CameraInfo(
            connectionId,
            if (isBackCamera) CameraLensFacing.BACK else CameraLensFacing.FRONT,
            rgbPreviewId, // RGB preview texture ID
            CameraSize(
                cameraController.previewResolution.width.toLong(),
                cameraController.previewResolution.height.toLong(),
            ),
            false,
            cameraController.sensorOrientation.toLong(),
            CameraSize(
                cameraController.hiresResolution.width.toLong(),
                cameraController.hiresResolution.height.toLong(),
            ),
            if (isBackCamera) CameraLensFacing.BACK else CameraLensFacing.FRONT, // IR lens facing
            irPreviewId, // IR preview texture ID
            CameraSize(
                cameraController.previewResolution.width.toLong(),
                cameraController.previewResolution.height.toLong(),
            ),
            false, // IR preview doesn't need flipping
        )
    }

}