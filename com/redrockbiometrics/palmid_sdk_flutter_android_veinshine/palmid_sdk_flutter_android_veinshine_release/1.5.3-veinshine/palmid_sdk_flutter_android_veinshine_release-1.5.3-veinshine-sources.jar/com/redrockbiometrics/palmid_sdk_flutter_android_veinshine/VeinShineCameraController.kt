package com.redrockbiometrics.palmid_sdk_flutter_android_veinshine

import android.app.Activity
import android.content.Context
import android.util.Log
import android.util.Size
import android.view.Surface
import androidx.lifecycle.DefaultLifecycleObserver
import com.api.stream.Device
import com.api.stream.Frame
import com.api.stream.FrameType
import com.api.stream.Frames
import com.api.stream.IDevice
import com.api.stream.IOpenCallback
import com.api.stream.IStream
import com.api.stream.PalmSdk
import com.api.stream.StreamType
import com.api.stream.manager.DtUsbDevice
import com.api.stream.manager.DtUsbManager
import com.api.stream.manager.UsbMapTable
import com.api.stream.veinshine.IVeinshine
import io.flutter.view.TextureRegistry.SurfaceProducer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.TimeUnit

class VeinShineCameraController(
    private val activity: Activity,
    private val rgbPreviewSurfaceProducer: SurfaceProducer,
    private val irPreviewSurfaceProducer: SurfaceProducer,
    private val debugIrPreview: Boolean = false,
    private val onImage: (CameraImage) -> Unit,
) : DefaultLifecycleObserver {
    
    // LED Mode Enum
    enum class LedMode(val value: Int) {
        OFF(0),
        BLUE(3),
        STANDBY(20),
    }

    // Configuration constants
    companion object {
        private const val TAG = "VeinShineCameraController"
        private const val DEFAULT_PREVIEW_WIDTH = 720
        private const val DEFAULT_PREVIEW_HEIGHT = 960
        private const val STREAM_TIMEOUT_MS = 2000L
        private const val IMAGE_THROTTLE_MS = 66L

        fun getDebugInfo(context: Context): String {
            return buildString {
                append("VeinShine Camera Controller Debug Info\n")
                append("SDK Version: ${PalmSdk.getSdkVersion()}\n")
                append("Device Type: VeinShine\n")
                append("Preview Resolution: ${DEFAULT_PREVIEW_WIDTH}x${DEFAULT_PREVIEW_HEIGHT}\n")
            }
        }
    }

    val sensorOrientation = 0
    val previewResolution = Size(DEFAULT_PREVIEW_WIDTH, DEFAULT_PREVIEW_HEIGHT)
    val hiresResolution = previewResolution

    private var rgbPreviewSurface: Surface? = null
    private var irPreviewSurface: Surface? = null
    
    // GPU 渲染器 - 使用 OpenGL ES 进行高性能渲染
    private var rgbGLRenderer: SurfaceGLRenderer? = null
    private var irGLRenderer: SurfaceGLRenderer? = null
    
    private val lastImageSentNs = AtomicLong(0)
    private val imageThrottleNs = TimeUnit.MILLISECONDS.toNanos(IMAGE_THROTTLE_MS)
    
    private val isRunning = AtomicBoolean(false)
    private var device: IDevice? = null
    private var activeStream: IStream? = null
    private var streamThread: Thread? = null

    private var rgbFrameData: ByteArray? = null
    private var irFrameData: ByteArray? = null
    private var irFrameW = 0
    private var irFrameH = 0
    private var rgbFrameW = 0
    private var rgbFrameH = 0

    fun open() {
        if (isRunning.get()) {
            Log.w(TAG, "Camera already open")
            return
        }

        // Set surface sizes
        rgbPreviewSurfaceProducer.setSize(previewResolution.width, previewResolution.height)
        rgbPreviewSurface = rgbPreviewSurfaceProducer.surface
        
        irPreviewSurfaceProducer.setSize(previewResolution.width, previewResolution.height)
        irPreviewSurface = irPreviewSurfaceProducer.surface
        
        // 初始化 OpenGL 渲染器
        try {
            rgbGLRenderer = SurfaceGLRenderer(
                rgbPreviewSurface!!,
                previewResolution.width,
                previewResolution.height
            )
            irGLRenderer = SurfaceGLRenderer(
                irPreviewSurface!!,
                previewResolution.width,
                previewResolution.height
            )
            Log.i(TAG, "✅ GPU renderers initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize GPU renderers, will fallback", e)
        }

        Device.create(activity, object : Device.DeviceListener {
            override fun onDeviceCreatedSuccess(
                device: IDevice,
                deviceIndex: Int,
                runningDevice: Map<Long, IDevice>,
                deviceType: UsbMapTable.DeviceType
            ) {
                if (deviceIndex == 1) {
                    openDevice(device)
                }
            }

            override fun onDeviceCreateFailed(device: IDevice) {
                Log.e(TAG, "Device creation failed")
                isRunning.set(false)
            }

            override fun onDeviceDestroy(device: IDevice) {
                Log.d(TAG, "Device destroyed")
                cleanup()
            }
        }, object : DtUsbManager.DeviceStateListener {
            override fun onDevicePermissionGranted(dtUsbDevice: DtUsbDevice) {}
            override fun onDevicePermissionDenied(dtUsbDevice: DtUsbDevice) {
                Log.e(TAG, "Camera permission denied")
            }
            override fun onAttached(dtUsbDevice: DtUsbDevice) {}
            override fun onDetached(dtUsbDevice: DtUsbDevice) {
                cleanup()
            }
        })
    }

    private fun openDevice(dev: IDevice) {
        dev.open(object : IOpenCallback {
            override fun onDownloadPrepare() {
                Log.d(TAG, "Firmware download prepare")
            }

            override fun onDownloadProgress(progress: Int) {
                Log.d(TAG, "Firmware download progress: $progress")
            }

            override fun onDownloadSuccess() {
                Log.d(TAG, "Firmware download success")
            }

            override fun onOpenSuccess() {
                Log.d(TAG, "Device opened successfully")
                device = dev
                
                (dev as IVeinshine).setLedMode(LedMode.STANDBY.value)
                val deviceInfo = dev.deviceInfo
                Log.d(TAG, "Device info: $deviceInfo")

                val supportedStreams = dev.deviceSupportStreamType
                if (supportedStreams.isNotEmpty()) {
                    startStream(dev, supportedStreams[0])
                }
            }

            override fun onOpenFail(errorCode: Int) {
                Log.e(TAG, "Device open failed: $errorCode")
                isRunning.set(false)
            }
        })
    }

    private fun startStream(dev: IDevice, streamType: StreamType) {
        try {
            val stream = dev.createStream(streamType) ?: run {
                Log.e(TAG, "Failed to create stream")
                return
            }
            
            val frames = stream.allocateFrames()
            val ret = stream.start()
            if (ret != 0) {
                Log.e(TAG, "Failed to start stream: $ret")
                return
            }

            activeStream = stream
            isRunning.set(true)
            lastImageSentNs.set(0)

            // Start stream processing thread
            streamThread = Thread {
                processStream(stream, frames)
            }.apply {
                name = "VeinShine-Stream"
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting stream", e)
        }
    }

    private fun processStream(stream: IStream, frames: Frames) {
        Log.d(TAG, "Stream processing started")
        try {
            while (isRunning.get() && !Thread.currentThread().isInterrupted) {
                try {
                    val res = stream.getFrames(frames, STREAM_TIMEOUT_MS.toInt())
                    if (res != 0) {
                        continue
                    }

                    val frame1 = frames.getFrame(0)
                    val frame2 = frames.getFrame(1)

                    try {
                        processFrames(frame1, frame2)
                    } finally {
                        frame1?.release()
                        frame2?.release()
                    }
                } catch (e: InterruptedException) {
                    Log.d(TAG, "Stream processing interrupted")
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing frames", e)
                    if (!isRunning.get()) break
                }
            }
        } finally {
            Log.d(TAG, "Stream processing ended")
        }
    }

    private fun processFrames(frame1: Frame?, frame2: Frame?) {
        // Extract frame data
        processFrame(frame1)
        processFrame(frame2)

        // Send image callback (with throttling)
        if (shouldSendImage()) {
            try {
                val cameraImage = createRgbIrImage()
                onImage(cameraImage)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to send image callback", e)
            }
        }

        // Render to surfaces
        renderFrames()
    }

    private fun processFrame(frame: Frame?) {
        frame?.let { f ->
            when (f.frameType) {
                FrameType.RGB_FRAME -> {
                    rgbFrameW = f.width
                    rgbFrameH = f.height
                    val data = f.rawData
                    if (data != null) {
                        if (rgbFrameData == null || rgbFrameData!!.size != data.size) {
                            rgbFrameData = ByteArray(data.size)
                        }
                        System.arraycopy(data, 0, rgbFrameData!!, 0, data.size)
                    }
                }
                FrameType.IR_FRAME -> {
                    irFrameW = f.width
                    irFrameH = f.height
                    val data = f.rawData
                    if (data != null) {
                        if (irFrameData == null || irFrameData!!.size != data.size) {
                            irFrameData = ByteArray(data.size)
                        }
                        System.arraycopy(data, 0, irFrameData!!, 0, data.size)
                    }
                }
                else -> {}
            }
        }
    }

    private fun shouldSendImage(): Boolean {
        if (rgbFrameData == null || irFrameData == null) {
            return false
        }

        if (imageThrottleNs <= 0L) {
            return true
        }

        val now = System.nanoTime()
        var last = lastImageSentNs.get()
        while (true) {
            if (now - last < imageThrottleNs && last != 0L) {
                return false
            }
            if (lastImageSentNs.compareAndSet(last, now)) {
                return true
            }
            last = lastImageSentNs.get()
        }
    }

    private fun createRgbIrImage(): CameraImage {
        val plane0 = CameraImagePlane(
            width = rgbFrameW.toLong(),
            height = rgbFrameH.toLong(),
            format = CameraImageFormat.RGB888,
            data = rgbFrameData!!,
            isActiveLighting = true,
            isRearFacingCamera = false,
            isCameraAdjusted = true,
            timestamp = System.currentTimeMillis(),
            metadata = emptyMap(),
        )

        val plane1 = CameraImagePlane(
            width = irFrameW.toLong(),
            height = irFrameH.toLong(),
            format = CameraImageFormat.Y8,
            data = irFrameData!!,
            isActiveLighting = true,
            isRearFacingCamera = false,
            isCameraAdjusted = true,
            timestamp = System.currentTimeMillis(),
            metadata = emptyMap(),
        )

        return CameraImage(
            width = plane0.width,
            height = plane0.height,
            format = CameraImageFormat.RGB888,
            planes = listOf(plane0, plane1),
            isActiveLighting = true,
            isRearFacingCamera = false,
            isCameraAdjusted = true,
            timestamp = plane0.timestamp,
            metadata = emptyMap(),
        )
    }

    private fun renderFrames() {
        if (!isRunning.get()) return

        val rgbData = rgbFrameData
        val irData = irFrameData
        
        // 优先使用 GPU 渲染
        if (rgbGLRenderer != null && irGLRenderer != null) {
            try {
                if (rgbData != null && rgbFrameW > 0 && rgbFrameH > 0) {
                    rgbGLRenderer?.renderRGB(rgbData, rgbFrameW, rgbFrameH)
                }
                if (irData != null && irFrameW > 0 && irFrameH > 0) {
                    irGLRenderer?.renderGray(irData, irFrameW, irFrameH)
                }
            } catch (e: Exception) {
                Log.e(TAG, "GPU rendering failed, disabling GPU renderer", e)
                // GPU 渲染失败，禁用它以触发 Fallback
                rgbGLRenderer?.release()
                irGLRenderer?.release()
                rgbGLRenderer = null
                irGLRenderer = null
            }
        } else {
            // GPU 不可用，使用 Native + ByteBuffer 直接渲染（最简单的 Fallback）
            // 注意：这个版本不会看到画面，但至少不会崩溃
            // TODO: 如果需要，可以添加完整的 Canvas 渲染 Fallback
            Log.w(TAG, "GPU renderer not available, rendering disabled")
        }
    }


    fun close() {
        Log.d(TAG, "Closing camera")
        
        if (!isRunning.get()) {
            Log.w(TAG, "Camera already closed")
            return
        }
        
        isRunning.set(false)

        // Stop stream first - this will cause getFrames() to return immediately
        activeStream?.let { stream ->
            try {
                stream.stop()
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping stream", e)
            }
        }

        // Wait for stream thread to exit (should be very quick after stop())
        streamThread?.let { thread ->
            try {
                thread.join(1000)  // Wait max 1 second
            } catch (e: InterruptedException) {
                Log.w(TAG, "Interrupted while waiting for stream thread")
                Thread.currentThread().interrupt()
            }
        }
        streamThread = null

        // Destroy stream
        activeStream?.let { stream ->
            try {
                device?.destroyStream(stream)
            } catch (e: Exception) {
                Log.e(TAG, "Error destroying stream", e)
            }
        }
        activeStream = null

        // Close device
        device?.let { dev ->
            try {
                (dev as IVeinshine).setLedMode(LedMode.BLUE.value)
                dev.close()
            } catch (e: Exception) {
                Log.e(TAG, "Error closing device", e)
            }
        }
        device = null

        cleanup()
        
        Log.d(TAG, "Camera closed")
    }

    private fun cleanup() {
        rgbFrameData = null
        irFrameData = null
        
        // 释放 OpenGL 资源
        try {
            rgbGLRenderer?.release()
            irGLRenderer?.release()
            rgbGLRenderer = null
            irGLRenderer = null
            Log.d(TAG, "GPU renderers released")
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing GPU renderers", e)
        }
        
        lastImageSentNs.set(0)
        isRunning.set(false)
    }
}
