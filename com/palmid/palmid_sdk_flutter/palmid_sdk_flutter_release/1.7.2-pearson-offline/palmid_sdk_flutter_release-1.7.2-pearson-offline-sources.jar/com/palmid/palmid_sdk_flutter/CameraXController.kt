package com.palmid.palmid_sdk_flutter

import android.app.ActivityManager
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.util.Log
import android.util.Size
import android.view.Surface
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.core.SurfaceRequest
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ExperimentalCameraProviderConfiguration
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.abs


@ExperimentalCamera2Interop
class CameraXController(
    private val context: Context,
    val cameraId: String,
    private val analyzerFormat: CameraImageFormat = CameraImageFormat.RGBA8888,
    private val previewSurfaceTexture: SurfaceTexture,
    private val resolutionRequest: Size,
    private val flashModeRequest: CameraFlashMode,
    private val targetAreaSize: Int,
    private val onImage: (CameraImage) -> Unit,
) : DefaultLifecycleObserver {
    private var cameraProvider: ProcessCameraProvider? = null

    private val flashMode: Int by lazy {
        when (flashModeRequest) {
            CameraFlashMode.TORCH -> CaptureRequest.FLASH_MODE_TORCH
            CameraFlashMode.OFF -> CaptureRequest.FLASH_MODE_OFF
            CameraFlashMode.AUTO -> if (characteristics.hasTorch) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF
        }
    }
    private val isActiveLightning: Boolean
        get() = flashMode == CaptureRequest.FLASH_MODE_TORCH

    val sensorOrientation: Int by lazy {
        characteristics.sensorOrientation
    }

    val lensDirection: Int by lazy {
        characteristics.get(CameraCharacteristics.LENS_FACING)!!
    }

    val previewResolution: Size by lazy {
        val hiresRatio = hiresResolution.width.toDouble() / hiresResolution.height
        val sizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            .getOutputSizes(ImageFormat.YUV_420_888)
        val size = sizes.filter {
            it.width >= resolutionRequest.width && it.height >= resolutionRequest.height
        }.filter {
            abs(it.width.toDouble() / it.height - hiresRatio) < 0.1f
        }.minByOrNull { it.width * it.height }
        size ?: sizes.maxBy { it.width * it.height }
    }

    val hiresResolution: Size by lazy {
        characteristics.maxJpegSize
    }

    var dropFramesWhenCameraAdjusting: Boolean
        get() = analyzer.dropFramesWhenCameraAdjusting
        set(value) {
            analyzer.dropFramesWhenCameraAdjusting = value
        }

    suspend fun open() {
        initializeCamera()
    }

    fun close() {
        cancelCaptureHiresPhoto()
        try {
            analysis.clearAnalyzer()
        } catch (e: Exception) {
            Log.w(TAG, "Error clearing analyzer", e)
        }
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            // Camera may already be in error state (CAMERA_ERROR)
            Log.w(TAG, "Error while closing camera", e)
        }
        try {
            if (!analyzerExecutor.isShutdown) {
                analyzerExecutor.shutdownNow()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error shutting down executor", e)
        }
    }

    private val cameraState: CameraState by lazy {
        CameraState(
            isAutoFocusEnabled = characteristics.isAutoFocusEnabled && !characteristics.isMotorolaDevice,
            gainRange = characteristics.gainRange,
            focusRange = characteristics.adjustedFocusRange,
        )
    }

    private val analyzerImageProducer: CameraImageProducer by lazy {
        CameraImageProducer(analyzer, cameraState).also {
            it.onImage = onImage
        }
    }

    private val characteristics: CameraCharacteristicsHelper by lazy {
        CameraCharacteristicsHelper(
            cameraManager.getCameraCharacteristics(cameraId),
            if (isLowRamDevice) 15 else 30,
        )
    }

    private val isLowRamDevice: Boolean by lazy {
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).isLowRamDevice
    }

    private val cameraManager: CameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }

    private val analyzerExecutor by lazy { Executors.newSingleThreadExecutor() }

    private val preview by lazy {
        Preview.Builder()
            .setResolutionSelector(
                // preview may not support previewResolution, fallback to closest lower
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(previewResolution, ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER)
                    )
                    .build()
            )
            .build()

    }

    private val analyzer: IPreviewImageAnalyzer by lazy {
        if (analyzerFormat == CameraImageFormat.RGBA8888)
            Rgba8888PreviewImageAnalyzer(
                cameraState,
                isActiveLightning,
                !characteristics.isFrontFacing,
                false,
            ) {}
        else
            PreviewImageAnalyzer(
                cameraState,
                isActiveLightning,
                !characteristics.isFrontFacing,
                false,
            ) {}
    }

    private val analysis by lazy {
        ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(previewResolution, ResolutionStrategy.FALLBACK_RULE_NONE)
                    )
                    .build()
            )
            .setOutputImageFormat(
                if (analyzerFormat == CameraImageFormat.RGBA8888)
                ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888
                else ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .apply {
                val ext = Camera2Interop.Extender(this)
                ext.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, characteristics.aeFps)
                ext.setSessionCaptureCallback(analyzerImageProducer.captureCallback)
            }
            .build()
            .apply {
                setAnalyzer(analyzerExecutor, analyzer)
            }
    }
    private val imageCapture by lazy {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .build()
            )
            .apply {
                val ext = Camera2Interop.Extender(this)
                ext.setSessionCaptureCallback(hiresImageProducer.captureCallback)
            }
            .build()
    }

    private fun createFocusMeteringAction(): FocusMeteringAction {
        val meteringPoint = SurfaceOrientedMeteringPointFactory(1f, 1f)
            .createPoint(.5f, .5f)
        
        return FocusMeteringAction.Builder(meteringPoint)
            .addPoint(meteringPoint, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(1, TimeUnit.SECONDS)
            .build()
    }

    private var camerax: Camera? = null
    fun resetAutoFocusIfEnabled() {
        camerax?.apply {
            val focusMeteringAction = createFocusMeteringAction()
            if (cameraInfo.isFocusMeteringSupported(focusMeteringAction)) {
                try {
                    cameraControl.startFocusAndMetering(focusMeteringAction)
                } catch (e: Exception) {
                    Log.d("ERROR", "cannot focus camera", e)
                }
            }
        }
    }

    @OptIn(ExperimentalCameraProviderConfiguration::class)
    @ExperimentalCamera2Interop
    private suspend fun initializeCamera() {
        val cameraProvider = ProcessCameraProvider.getInstance(context).await()
        this.cameraProvider = cameraProvider

        val cameraSelector = CameraSelector.Builder()
            .addCameraFilter {list ->
                list.filter { Camera2CameraInfo.from(it).cameraId == cameraId }
            }.build()

        preview.setSurfaceProvider(SurfaceProvider(previewSurfaceTexture))

        try {
            cameraProvider.unbindAll()

            val camera = cameraProvider.bindToLifecycle(context as LifecycleOwner, cameraSelector, preview, imageCapture, analysis)
            val cameraControl = camera.cameraControl
            camerax = camera

            if (isActiveLightning) {
                cameraControl.enableTorch(true)
            }

            val zoom = characteristics.getZoomLevelForArea(targetAreaSize)
            if (zoom > 1) {
                cameraControl.setZoomRatio(zoom)
            }
        } catch(e: Exception) {
            Log.e(TAG, "Use case binding failed", e)
            throw e
        }
    }

    private val onImageCapturedCallback: OnImageCaptured by lazy {
        OnImageCaptured(
            isActiveLightning,
            !characteristics.isFrontFacing,
        ) {}
    }

    private val hiresImageProducer: CameraImageProducer by lazy {
        CameraImageProducer(onImageCapturedCallback, cameraState, true)
    }

    private val hiresCaptureJob = SupervisorJob()
    private val hiresCaptureScope = CoroutineScope(Dispatchers.Default + hiresCaptureJob)

    fun cancelCaptureHiresPhoto() {
        hiresCaptureScope.coroutineContext.cancelChildren()
    }

    suspend fun captureHiresPhoto(): CameraImage {
        hiresCaptureScope.coroutineContext.cancelChildren()

        return hiresCaptureScope.run { suspendCancellableCoroutine { cont ->
            hiresImageProducer.onImage = {
                hiresImageProducer.onImage = {}
                if (cont.isActive) cont.resume(it)
            }

            imageCapture.takePicture(ContextCompat.getMainExecutor(context), onImageCapturedCallback)
            cont.invokeOnCancellation {
                hiresImageProducer.onImage = {}
            }
        }}
    }

    companion object {
        const val TAG = "CameraXController"

        fun getDebugInfoForCameraId(context: Context, cameraId: String): String {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val keys = characteristics.keys.toMutableList()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                keys.add(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                keys.add(CameraCharacteristics.FLASH_INFO_STRENGTH_DEFAULT_LEVEL)
            }

            val helper = CameraCharacteristicsHelper(characteristics, 30)

            val s = listOf(
                "isEmulator: ${helper.isEmulator}",
                "isAutoFocusEnabled: ${helper.isAutoFocusEnabled}",
                "isLowRamDevice: ${(context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).isLowRamDevice}",
                "Build.PRODUCT: ${Build.PRODUCT}",
                "Build.FINGERPRINT: ${Build.FINGERPRINT}",
                "Build.HARDWARE: ${Build.HARDWARE}",
                "Build.BRAND: ${Build.BRAND}",
                "Build.MANUFACTURER: ${Build.MANUFACTURER}",
                "Build.MODEL: ${Build.MODEL}",
                "Build.VERSION.RELEASE: ${Build.VERSION.RELEASE}",
                "Build.VERSION.SDK_INT: ${Build.VERSION.SDK_INT}",
            ).joinToString(separator = "\n") + "\n"

            return s + keys.joinToString(separator = "\n") { key ->
                var value = characteristics.get(key)
                value = when (value) {
                    is Array<*> -> value.joinToString(separator = ", ")
                    is ArrayList<*> -> value.joinToString(separator = ", ")
                    is IntArray -> value.joinToString(separator = ", ")
                    is FloatArray -> value.joinToString(separator = ", ")
                    is BooleanArray -> value.joinToString(separator = ", ")
                    else -> value.toString()
                }
                "${key.name.removePrefix("android.")}: {$value}"
            }
        }

        fun getCameraIdByLensFacing(context: Context, lensFacing: Int): String {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            return manager.cameraIdList.first {
                manager.getCameraCharacteristics(it)
                    .get(CameraCharacteristics.LENS_FACING) == lensFacing
            }
        }
    }
}

class SurfaceProvider(
    private val previewSurfaceTexture: SurfaceTexture,
) : Preview.SurfaceProvider {
    override fun onSurfaceRequested(request: SurfaceRequest) {
        previewSurfaceTexture.setDefaultBufferSize(request.resolution.width, request.resolution.height)
        val surface = Surface(previewSurfaceTexture)

        request.provideSurface(surface, Executors.newSingleThreadExecutor()) {
            surface.release()
        }
    }
}

///**
// * TODO: use with SurfaceProducer
// * Creates a [Preview.SurfaceProvider] that specifies how to provide a [Surface] to a
// * `Preview` that is backed by a Flutter [TextureRegistry.SurfaceTextureEntry].
// */
//fun createSurfaceProvider(
//    surfaceProducer: SurfaceProducer
//): Preview.SurfaceProvider {
//    return Preview.SurfaceProvider { request ->
//        surfaceProducer.setCallback(
//            object : SurfaceProducer.Callback {
//                override fun onSurfaceCreated() {
//                }
//
//                override fun onSurfaceDestroyed() {
//                    request.invalidate()
//                }
//            })
//
//        surfaceProducer.setSize(
//            request.resolution.width, request.resolution.height
//        )
//        val flutterSurface = surfaceProducer.surface
//        request.provideSurface(
//            flutterSurface,
//            Executors.newSingleThreadExecutor()
//        ) { _ ->
//            flutterSurface.release()
//        }
//    }
//}
