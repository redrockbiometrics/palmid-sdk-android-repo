package com.redrockbiometrics.palmid_sdk_flutter_android_veinshine.common.opengl;

public interface ISimplePlayer {

  public void onPlayStart();

  public void onReceiveState(int state);
}
