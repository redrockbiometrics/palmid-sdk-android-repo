package com.palmid.palmid_sdk_flutter

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Size
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.view.TextureRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlin.coroutines.EmptyCoroutineContext

/** PalmidSdkFlutterPlugin */
class PalmidSdkFlutterPlugin : FlutterPlugin, ActivityAware {
    private var flutterPluginBinding: FlutterPlugin.FlutterPluginBinding? = null

    override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        this.flutterPluginBinding = flutterPluginBinding
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        this.flutterPluginBinding = null
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        CameraControllerHostApi.setUp(
            flutterPluginBinding!!.binaryMessenger,
            PalmidSdkMethodCallHandler(
                binding.activity,
                flutterPluginBinding!!.textureRegistry,
                CameraControllerFlutterApi(flutterPluginBinding!!.binaryMessenger),
            ),
        )
    }

    override fun onDetachedFromActivity() {
        CameraControllerHostApi.setUp(
            flutterPluginBinding!!.binaryMessenger,
            null
        )
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity()
    }
}

@OptIn(ExperimentalCamera2Interop::class)
class PalmidSdkMethodCallHandler(
    private val context: Context,
    private val textureRegistry: TextureRegistry,
    private val flutterApi: CameraControllerFlutterApi,
) : CameraControllerHostApi {
    private val coroutineScope = CoroutineScope(EmptyCoroutineContext)

    private val openedCameras =
        mutableMapOf<String, Pair<CameraXController, TextureRegistry.SurfaceTextureEntry>>()

    override fun openCamera(
        cameraSelector: CameraSelectorData,
        settings: CameraCaptureSettingsData,
        callback: (Result<CameraInfo>) -> Unit
    ) {
        try {
            callback(Result.success(openCameraImpl(cameraSelector, settings)))
        } catch (e: Throwable) {
            callback(Result.failure(e))
        }
    }

    override fun captureHiresPhoto(connectionId: String, callback: (Result<CameraImage>) -> Unit) {
        try {
            callback(Result.success(captureHiresPhotoImpl(connectionId)))
        } catch (e: Throwable) {
            callback(Result.failure(e))
        }
    }

    override fun sendCaptureHiresPhotoRequest(connectionId: String) {
        coroutineScope.launch {
            try {
                val image = captureHiresPhotoImpl(connectionId)
                Handler(Looper.getMainLooper()).post {
                    flutterApi.onHiresImage(image) {}
                }
            } catch (e: CancellationException) {
                //
            }
        }
    }

    override fun cancelCaptureHiresPhotoRequest(connectionId: String) {
        val controller = openedCameras[connectionId]!!.first
        controller.cancelCaptureHiresPhoto()
    }

    override fun sendResetAutofocusRequest(connectionId: String) = runBlocking {
        val controller = openedCameras[connectionId]!!.first
        controller.resetAutoFocusIfEnabled()
    }

    override fun getDebugCameraInfo(cameraSelector: CameraSelectorData): String {
        val cameraId = getCameraIdForSelector(cameraSelector)
        return CameraXController.getDebugInfoForCameraId(context, cameraId)
    }

    override fun setDropFramesDuringCameraAdjustment(connectionId: String, drop: Boolean) {
        openedCameras[connectionId]?.apply {
            this.first.dropFramesWhenCameraAdjusting = drop
        }
    }

    private fun closeAllConnectionsFor(cameraId: String) {
        openedCameras
            .filter { it.value.first.cameraId == cameraId }
            .forEach {
                closeCamera(it.key)
            }
    }

    override fun closeCamera(connectionId: String): Unit = runBlocking {
        openedCameras.remove(connectionId)?.apply{ closeOpenedCamera(this) }
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun closeOpenedCamera(info: Pair<CameraXController, TextureRegistry.SurfaceTextureEntry>) : Unit = runBlocking {
        try {
            info.first.close()
        } catch (e: Exception) {
            // Log error but continue with cleanup
            android.util.Log.w("PalmidSdkFlutterPlugin", "Error closing camera controller: ${e.message}", e)
        }
        try {
            info.second.release()
        } catch (e: Exception) {
            // Log error but don't throw
            android.util.Log.w("PalmidSdkFlutterPlugin", "Error releasing surface texture: ${e.message}", e)
        }
    }

    override fun dispose() = runBlocking {
        openedCameras.forEach {
            closeOpenedCamera(it.value)
        }
        openedCameras.clear()
    }

    private fun openCameraImpl(
        cameraSelector: CameraSelectorData,
        settings: CameraCaptureSettingsData
    ): CameraInfo {
        val cameraId = getCameraIdForSelector(cameraSelector)
        closeAllConnectionsFor(cameraId)

        val flutterSurfaceTexture = textureRegistry.createSurfaceTexture()
        // TODO: move to SurfaceProducer
        // val flutterSurfaceProducer = textureRegistry.createSurfaceProducer()
        val cameraController = CameraXController(
            context,
            cameraId,
            CameraImageFormat.RGBA8888,
            flutterSurfaceTexture.surfaceTexture(),
            Size(settings.sizeRequest.width.toInt(), settings.sizeRequest.height.toInt()),
            settings.flashMode,
            settings.minFocusedSubjectSize.toInt(),
        ) {
            Handler(Looper.getMainLooper()).post {
                flutterApi.onImage(it) {}
            }
        }
        val previewId = flutterSurfaceTexture.id()
        val connectionId = previewId.toString()
        openedCameras[connectionId] = Pair(cameraController, flutterSurfaceTexture)
        runBlocking { cameraController.open() }
        return CameraInfo(
            connectionId,
            CameraLensFacing.ofRaw(cameraController.lensDirection)!!,
            previewId,
            CameraSize(
                cameraController.previewResolution.width.toLong(),
                cameraController.previewResolution.height.toLong(),
            ),
            false,
            cameraController.sensorOrientation.toLong(),
            CameraSize(
                cameraController.hiresResolution.width.toLong(),
                cameraController.hiresResolution.height.toLong(),
            )
        )
    }

    private fun captureHiresPhotoImpl(connectionId: String): CameraImage = runBlocking {
        val controller = openedCameras[connectionId]!!.first
        controller.captureHiresPhoto()
    }

    private fun getCameraIdForSelector(cameraSelector: CameraSelectorData): String =
        cameraSelector.cameraId ?: CameraXController.getCameraIdByLensFacing(
            context,
            cameraSelector.lensFacing!!.raw,
        )
}