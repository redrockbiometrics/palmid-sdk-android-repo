package com.palmid.palmid_sdk_flutter

import android.hardware.camera2.CameraMetadata.CONTROL_AE_STATE_CONVERGED
import android.hardware.camera2.CameraMetadata.CONTROL_AF_STATE_PASSIVE_UNFOCUSED
import android.hardware.camera2.CaptureResult
import android.os.Build
import android.util.Range

data class CameraState(
    var aeState: Int = CONTROL_AE_STATE_CONVERGED,
    var afState: Int = CONTROL_AF_STATE_PASSIVE_UNFOCUSED,
    var exposure: Long? = null,
    var rawGain: Int? = null,
    var focusDistance: Float? = null,
    private val isAutoFocusEnabled: Boolean = false,
    private val gainRange: Range<Int>,
    private val focusRange: Range<Float> = Range(2f, Float.POSITIVE_INFINITY),
) {
    val gain: Int?
        get() = rawGain?.let { gainRange.clamp(it) }

    val isLenovoDevice: Boolean
        get() = Build.MANUFACTURER.lowercase().contains("lenovo")

    val isFocused: Boolean
        get() {
            if (!isAutoFocusEnabled) {
                return afState == CaptureResult.CONTROL_AF_STATE_INACTIVE
            }

            if (
                afState != CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED
                && afState != CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED
                && afState != CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                && afState != CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
            ) {
                return false
            }
            // return focusDistance?.let { focusRange.contains(it) } ?: true
            return focusDistance?.let {
                if (isLenovoDevice && it < 0) {
                    true
                } else {
                    focusRange.contains(it)
                }
            } ?: true
        }

    val isAfLocked: Boolean
        get() {
            return afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                || afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
        }


    val isAeConverged: Boolean
        get() = aeState != CaptureResult.CONTROL_AE_STATE_INACTIVE
                && aeState != CaptureResult.CONTROL_AE_STATE_SEARCHING


    val isExposureFinished: Boolean
        get() = aeState != CaptureResult.CONTROL_AE_STATE_INACTIVE
                && aeState != CaptureResult.CONTROL_AE_STATE_SEARCHING

    val isAdjusted: Boolean
        get() = isFocused && isExposureFinished

    fun updateFrom(state: CameraState) {
        aeState = state.aeState
        afState = state.afState
        exposure = state.exposure
        rawGain = state.rawGain
        focusDistance = state.focusDistance
    }
}